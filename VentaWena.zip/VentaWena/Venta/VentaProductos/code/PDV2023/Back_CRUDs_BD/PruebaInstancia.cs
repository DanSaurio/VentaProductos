﻿
using System;
namespace Back_CRUDs_BD
{
	public class PruebaInstancia
	{
		public PruebaInstancia()
		{
			
        }
    }
}

